import C from '../actions/constants'
import { combineReducers } from 'redux'
// import { browserHistory } from 'react-router-dom'
import _ from 'lodash';

const readableInitialState = {
  posts: [],
  categories: [],
  loading: false,
  error: null,
  selectedCategory: 'all',
  selectedPost: [],
};

export function categoriesReducer(state = readableInitialState, action) {
  switch(action.type) {

     // loading - to show spinner
    case C.BEGIN_FETCH_CATEGORIES:
      return {
        ...state,
        loading: true,
        error: null
      };

    // fetch errored
    case C.FETCH_CATEGORIES_FAILED:
    return {
      ...state,
      loading: false,
      error: action.payload.error.message.toString(),
      categories: []
    };

    // hide spinner, get categories from the server, save that to state
    case C.FETCH_CATEGORIES_SUCCESS:
      return {
        ...state,
        loading: false,
        categories: action.payload.categories
    };

    case C.SELECTED_CATEGORY:
      return {
        ...state,
        selectedCategory: action.payload.selectedCategory
    };

    default:
      return state;
  }
}

//Post Reducers

export function postsReducer(state = readableInitialState, action) {
  switch(action.type) {

    // loading - to show spinner
    case C.BEGIN_FETCH_POSTS :
      return {
        ...state,
        loading: true,
        error: null
      };

    // fetch errored
    case C.FETCH_POSTS_FAILED:
    return {
      ...state,
      loading: false,
      error: action.payload.error.message.toString(),
      posts: []
    };

    // hide spinner, get categories from the server, save that to state
    case C.FETCH_POSTS_SUCCESS:
      return {
        ...state,
        loading: false,
        posts: action.payload.posts
      };

      case C.GET_SELECTED_POST:
        return {
          ...state,
          loading: false,
          selectedPost: action.payload.post
      };

      case C.ADD_POST :

      const hasPost = state.posts.some(post => post.id === action.payload.postObj.id)
      console.log('this be getting added:', action.payload.postObj.id)
      return (hasPost) ?
         state :
         {
           ...state,
           posts: action.payload.postObj
         };

      case C.POST_VOTE_UP :
      console.log(action.payload.post)
      return {
        ...state,

      }

    // case.C.SORT_POSTS:
    //   return {
    //     ...state,
    //     posts: action.payload.posts,
    //     selectedPost
    //   }

    // case SORT_POSTS:
    // return {
    //   ...state,
    //   sortByCriteria: action.payload.sortByCriteria
    // };

    default:
      return state;
  }
}

const commentsInitialState = {
  comments: []
};
//
export function commentsReducer(state = commentsInitialState, action) {
  switch(action.type) {
//
    case C.FETCH_COMMENTS:
    const comments = _.mapKeys(action.payload.comments, 'id')
    console.log(JSON.stringify(comments));
      return {
        ...state,
        comments: comments
      };
//
    default:
      return state;
  }
}

export default combineReducers({
  categoriesReducer,
  postsReducer,
  commentsReducer
})
