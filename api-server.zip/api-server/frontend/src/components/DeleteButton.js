import React, { Component } from 'react';
import { withRouter } from 'react-router-dom'
import { connect } from "react-redux"
import FloatingActionButton from 'material-ui/FloatingActionButton';
import ContentClear from 'material-ui/svg-icons/content/clear';



import { deletePost } from '../actions'


class DeleteButton extends Component {

onDeleteObj(objId) {
  console.log(objId)
  this.props.deletePost(objId);
  this.props.history.push("/")
}

render() {

  const { obj } = this.props

  return(
    <div>
      <FloatingActionButton secondary={true} onClick={() => this.onDeleteObj(obj.id)}>
        <ContentClear />
      </FloatingActionButton>
    </div>
  )
}
}

const mapStateToProps = state => ({
  selectedPost: state.postsReducer.selectedPost,
  posts: state.postsReducer.posts,
});

function mapDispatchToProps (dispatch) {
  return {
    // getSpecificPost: (selectedPost) => dispatch(getSpecificPost(selectedPost)),
    deletePost: (objId) => dispatch(deletePost(objId)),
  }
}

export default withRouter(connect(
  mapStateToProps,
  mapDispatchToProps
)(DeleteButton))
