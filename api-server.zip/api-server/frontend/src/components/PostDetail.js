import React, { Component } from 'react';
import {Card, CardActions, CardHeader, CardText, CardTitle} from 'material-ui/Card';
import FlatButton from 'material-ui/FlatButton'
import Dialog from 'material-ui/Dialog';
import RaisedButton from 'material-ui/RaisedButton';
import TextField from 'material-ui/TextField';
import { Link, withRouter } from 'react-router-dom'
import { connect } from "react-redux"
// import Modal from 'react-modal'

import { getSpecificPost } from '../actions'
import Comments from './Comments'
import DeleteButton from './DeleteButton'

class PostDetail extends Component {
  state = {
    open: false,
  }

  openCommentModal = () => this.setState(() => ({
      open: true,
    }))
  closeCommentModal = () => this.setState(() => ({
      open: false,
    }))

componentWillMount(){
  console.log(this.props.posts)
}

componentDidMount() {
    const selectedPost = this.props.match.params.id
    console.log(selectedPost)
    this.props.getSpecificPost(selectedPost)
  }

render(){

  const { ...post }  = this.props.selectedPost;
  const actions = [
      <TextField
        hintText="Add your comment"
        multiLine={true}
        rows={3}
        textareaStyle={{
          width: '100%',
          margin: 'auto',
        }}
        fullWidth={true}
      />,
      <FlatButton
        label="Cancel"
        primary={true}
        onClick={this.closeCommentModal}
      />,
      <FlatButton
        label="Submit"
        primary={true}
        keyboardFocused={true}
        onClick={this.closeCommentModal}
      />,

    ];

    return (

      <div className="containers">
        <FlatButton
          label="Back to Main"
          containerElement={<Link to="/"/>}
        />

        <Card
          expanded={true}
          >
          <CardTitle actAsExpander={true} title={post.title} subtitle={`by ${post.author}`} />
          <CardHeader
            title={`Votes: ${post.voteScore}`}
            // subtitle={post.author}
            actAsExpander={true}
            showExpandableButton={false}
          />
          <CardActions>
            <DeleteButton obj={post}/>
            <FlatButton
              label="Vote Up"
              onClick={() => alert('Todo: vote-up score')}
            />
            <FlatButton
              label="Vote Down"
              onClick={() => alert('Todo: vote-down score')}
            />
            <RaisedButton label="Add Comment" onClick={this.openCommentModal} />
            <Dialog
              title="Leave a comment"
              actions={actions}
              modal={false}
              open={this.state.open}
              onRequestClose={this.closeCommentModal}
            >
              {/* The actions in this window were passed in as an array of React objects. */}
            </Dialog>
          </CardActions>
          <CardText expanded='true'>
            {post.body}
            <Comments postId={post.id}/>
            <h1>Post Detail Mothafucka!</h1>
          </CardText>
        </Card>
      </div>
    );
  }
}
const mapStateToProps = state => ({
  selectedPost: state.postsReducer.selectedPost,
  posts: state.postsReducer.posts,
});

function mapDispatchToProps (dispatch) {
  return {
    getSpecificPost: (selectedPost) => dispatch(getSpecificPost(selectedPost)),
    // deletePost: (post) => dispatch(deletePost(post)),
  }
}

export default withRouter(connect(
  mapStateToProps,
  mapDispatchToProps
)(PostDetail))

// export default PostDetail
