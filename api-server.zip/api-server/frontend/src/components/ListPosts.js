import React, { Component } from 'react';
import { withRouter } from 'react-router-dom'
import FloatingActionButton from 'material-ui/FloatingActionButton';
import TextField from 'material-ui/TextField';
import FlatButton from 'material-ui/FlatButton'
import ContentAdd from 'material-ui/svg-icons/content/add';
import Dialog from 'material-ui/Dialog';
import DropDownMenu from 'material-ui/DropDownMenu';
import MenuItem from 'material-ui/MenuItem';
import { connect } from "react-redux"

import { fetchPosts, getUUID, addPost } from '../actions'
// import Header from './Header'
import Loading from 'react-loading'
// import _ from 'lodash';

import PostPreview from './PostPreview'
import Categories from './Categories'
// import AddPost from './AddPost'

// import PostDetail from './PostDetail'

// const styles = {
//   customWidth: {
//     width: 200,
//   },
// };


class ListPosts extends Component {
  state = {
    open: false,
    body: '',
    value: 'react',
    title: '',
    author: '',
    timestamp: null,
    id: null,
  }



  componentWillMount() {
    const selectedCategory = this.props.selectedCategory;
    this.props.fetchPosts(selectedCategory);
    console.log('componentWillMount', selectedCategory)
  }

  openPostModal = () => this.setState(() => ({
      open: true,
    }))
  closePostModal = () => this.setState(() => ({
      open: false,
    }))

handleBodyChange = (e, value) => {
		e.preventDefault();
    // console.log('handlechange!', e.target.value)
		this.setState({ body: e.target.value });

	};

handleCategoryChange = (e, i, value) => {
    this.setState({value})
    console.log(this.state.value)
}

handleAuthorChange = (e, value) => {
    e.preventDefault();
    this.setState({ author: e.target.value });
    };

handleTitleChange = (e, value) => {
      e.preventDefault();
      this.setState({ title: e.target.value });
    };

  submit = (e) => {
  const body = this.state.body;
  const id = getUUID();
  const timestamp = new Date().toString();
  const category = this.state.value;
  const author = this.state.author;
  const title = this.state.title;
  const post = {
       id,
       timestamp,
       category,
       author,
       title,
       body,
    }
    this.props.addPost(post)
    this.setState({ body: '' })
    this.closePostModal()
  }

  render() {
    const { posts, error, loading } = this.props;
    // console.log(posts);
    const actions = [
      <TextField
        name="title"
        floatingLabelText="Title"
        value={this.state.title}
        onChange={this.handleTitleChange}
        fullWidth={false}
      />,
      <TextField
        name="author"
        floatingLabelText="Author"
        value={this.state.author}
        onChange={this.handleAuthorChange}
        fullWidth={false}
      />,
        <TextField
          name="body"
          floatingLabelText="Post Body"
          value={this.state.body}
          onChange={this.handleBodyChange}
          fullWidth={true}
        />,
        <FlatButton
          label="Cancel"
          primary={true}
          onClick={this.closePostModal}
        />,
        <FlatButton
          label="Submit"
          type="submit"
          primary={true}
          onClick={this.submit}
        />,
      ];


    return (
      <div>
        <Categories />

        <FloatingActionButton onClick={this.openPostModal}>
          <ContentAdd />
        </FloatingActionButton>
        <Dialog
          title="Make a Post"
          actions={actions}
          modal={false}
          open={this.state.open}
          onRequestClose={this.closePostModal}
        >
          <DropDownMenu
            value={this.state.value} onChange={this.handleCategoryChange}
            autoWidth={true}
          >
            <MenuItem value={"react"} primaryText="React" />
            <MenuItem value={"redux"} primaryText="Redux" />
            <MenuItem value={"udacity"} primaryText="Udacity" />

          </DropDownMenu>
          {/* The actions in this window were passed in as an array of React objects. */}
        </Dialog>

        {loading === true ? <div><Loading type='balls' color='#ff3647' className='loading' /></div> : null}
        {error !== undefined ? <div>{error}</div> : null}
          {!posts.length && !error
            ?
            <div className="noContentMsg">There are no posts in this category</div>
            :
            posts.map((post, i) => (
              <div key={i}>
                  <PostPreview post={ post } key={i}/>
              </div>

            ))
          }
      </div>
    )
  }
}


const mapStateToProps = (state, ownProps) => ({
  posts: state.postsReducer.posts,
  loading: state.postsReducer.loading,
  error: state.postsReducer.error,
  selectedCategory: state.categoriesReducer.selectedCategory,
  // selectedPost: state.postsReducer.selectedPost,
});

function mapDispatchToProps (dispatch) {
  return {
    fetchPosts: (selectedCategory) => dispatch(fetchPosts(selectedCategory)),
    addPost: (postObj) => dispatch(addPost(postObj)),
  }
}

export default withRouter(connect(
  mapStateToProps,
  mapDispatchToProps
)(ListPosts))
