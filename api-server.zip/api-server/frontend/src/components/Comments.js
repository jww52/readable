import React, { Component } from 'react';
import { connect } from "react-redux"
import { fetchComments } from '../actions'


class Comments extends Component {
  componentDidMount() {
    const { postId } = this.props;
    this.props.fetchComments(postId);
  }

  render() {
    const { comments } = this.props;
    console.log(JSON.stringify(comments));
    return (
      <div>
        {/* commentsForThePost.map((comment, i) => (
          <h1>{ comment.body }</h1>
        )) */}
      </div>
    )
  }
}

const mapStateToProps = state => ({
  comments: state.commentsReducer.comments
});

function mapDispatchToProps (dispatch) {
  return {
    fetchComments: (postId) => dispatch(fetchComments(postId))
  }
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
  )(Comments);
