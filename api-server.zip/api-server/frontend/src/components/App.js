import React, { Component } from 'react';
import { Switch, Route } from 'react-router-dom'

// import '../App.css';
// import Categories from './Categories'
import ListPosts from './ListPosts'
import Header from './Header'
import PostDetail from './PostDetail'


class App extends Component {

  render() {

    return (
      <div>
        <Header />
        <Switch>
          <Route exact path="/" component={ListPosts}/>
          <Route exact path="/:category" component={ListPosts}/>
          <Route exact path="/:category/:id" component={PostDetail}/>
        </Switch>
      </div>

         /* <Router> */
            /* <Route path="/" component={ListPosts}/> */

        // </Router>

        /* <Switch>
          {/* <ListPosts path="/"/> */
          /* const extraProps = { color: 'red' } */
          /* <Route path={`/category/:id`} render={(props) => (
            <PostDetail {...props}/>
          )}/> */
        // </Switch>



    );
  }
}

export default App;
