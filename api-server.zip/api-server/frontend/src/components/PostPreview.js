import React, { Component } from 'react';
import {Card, CardActions, CardHeader, CardText, CardTitle} from 'material-ui/Card';
import FlatButton from 'material-ui/FlatButton'
import { Link, withRouter } from 'react-router-dom'
import { connect } from "react-redux"
import { fetchPosts, getSpecificPost, postVote } from '../actions'

import DeleteButton from './DeleteButton'

class PostPreview extends Component {



  onVoteUp = (e, postId) => {
    e.preventDefault();
    postVote(postId, "upVote");
  }

  render() {
    const { post } = this.props

    return (
      <div>
        <Card>
          <CardTitle actAsExpander={true} title={post.title} subtitle={`by ${post.author}`} />
          <CardHeader
            title={`Votes: ${post.voteScore}`}
            actAsExpander={true}
            showExpandableButton={true}
          />
          <button onClick={(e) => this.onVoteUp(e, post.id)} >Vote Up
          </button>
          <CardActions>
            <FlatButton
              label="See Thread"
              containerElement={<Link to={`/${post.category}/${post.id}`} />}
            />
          </CardActions>
            <CardActions>
              <FlatButton
                label="Edit Post"
                onClick={() => alert('Todo: Edit Post functionality')}
              />

              <DeleteButton obj={post}/>
          </CardActions>
          <CardText expandable={true}>
            {post.body}
            <h1>Post Detail</h1>
          </CardText>
        </Card>
      </div>
    );
  }

}


const mapStateToProps = state => ({
  posts: state.postsReducer.posts,
  loading: state.postsReducer.loading,
  error: state.postsReducer.error,
  selectedCategory: state.categoriesReducer.selectedCategory,
  selectedPost: state.postsReducer.selectedPost,
});

function mapDispatchToProps (dispatch) {
  return {
    getSpecificPost: (selectedPost) => dispatch(getSpecificPost(selectedPost)),
    fetchPosts: (selectedCategory) => dispatch(fetchPosts(selectedCategory)),
    postVote: (postId, string) => dispatch(postVote(postId, string))
  }
}

export default withRouter(connect(
  mapStateToProps,
  mapDispatchToProps
)(PostPreview))
