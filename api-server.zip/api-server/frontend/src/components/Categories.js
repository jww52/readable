import React, { Component } from 'react'
import { NavLink, withRouter } from 'react-router-dom'
import { connect } from "react-redux"
import { fetchCategories, fetchPosts, getSelectedCategory } from '../actions'
import Loading from 'react-loading'

class CategoriesList extends Component {

  componentDidMount() {
    this.props.fetchCategories();
  }

  selectCategory = (selectedCategory) => {
    this.props.getSelectedCategory(selectedCategory);
    this.props.fetchPosts(selectedCategory);
  }

  render() {
    const { categories, error, loading } = this.props;
    return (
      <div className="col-md-3">
        <h2>Categories</h2>
        <div className="nav flex-column nav-pills" id="v-pills-tab" aria-orientation="vertical">

          {loading === true ? <div><Loading type='balls' color='#ff3647' className='loading' /></div> : null}
          {error !== undefined ? <div>{error}</div> : null}
          {!categories.length && !error
            ?
            <div className="noContentMsg">There are no categories in the source!</div>
            :
            categories.map((category, i) =>
              <NavLink to={`/${category.path}`} className="nav-link" activeClassName="active" key={i} onClick={() => this.selectCategory(category.name)}>{category.name}</NavLink>
            )
          }
        </div>
      </div>
    )
  }
}

const mapStateToProps = state => ({
  categories: state.categoriesReducer.categories,
  loading: state.categoriesReducer.loading,
  error: state.categoriesReducer.error,
  selectedCategory: state.categoriesReducer.selectedCategory
});

function mapDispatchToProps (dispatch) {
  return {
    fetchCategories: (data) => dispatch(fetchCategories()),
    getSelectedCategory: (selectedCategory) => dispatch(getSelectedCategory(selectedCategory)),
    fetchPosts: (selectedCategory) => dispatch(fetchPosts(selectedCategory))
  }
}

export default withRouter(connect(
  mapStateToProps,
  mapDispatchToProps
)(CategoriesList));
