import { api, headers } from '../utils/api'
import C from './constants'

export const beginFetchPosts = () => ({
  type: C.BEGIN_FETCH_POSTS,
})

export const fetchPostsFailed = (error) => ({
  type: C.FETCH_POSTS_FAILED,
  payload: { error },
})

export const fetchPostsSuccess = (posts) => ({
  type: C.FETCH_POSTS_SUCCESS,
  payload: { posts }
})

export const selectPostSuccess = (post) => ({
  type: C.GET_SELECTED_POST,
  payload: { post }
})

export const addPostSuccess = (postObj) => ({
  type: C.ADD_POST,
  payload: { postObj }
})

export const postVoteUpSuccess = (post) => {
  console.log("post: ", post)
  return {
  type: C.POST_VOTE_UP,
  payload: { post }
  }
}

export function fetchPosts(selectedCategory) {
  return dispatch => {
    dispatch(beginFetchPosts());
    return fetch(selectedCategory === 'all' ? `${api}/posts` : `${api}/${selectedCategory}/posts`, { headers })
      .then(
        res => res.json(),
        error => console.log('An error occurred.', error)
      )
      .then(json => {
        // console.log('fetch all posts',json)
        dispatch(fetchPostsSuccess(json));
        return json;
      })
    }
  }

  export function getSpecificPost(selectedPost){

  return (dispatch) => {
    dispatch(beginFetchPosts());
    const baseURL = selectedPost ? `${api}/posts/${selectedPost}` : null
      fetch(baseURL, {
        method: 'GET',
        headers: {
        ...headers,
        'content-type': 'application/json'
      },
    })
    .then(
          res => res.json(),
          error => console.log('An error occured at getSpecificPost', error)
        )
    .then(json => {
      // console.log(json)
      dispatch(selectPostSuccess(json))
      return json;
    })
  }
}

export function getUUID() {
  return (Math.random().toString(36).substring(2)+(new Date()).getTime().toString(36));
}

export const addPost = (postObj) => {
  return (dispatch) => {
  // console.log('addPost', postObj)
  fetch(`${api}/posts`, {
    method: 'POST',
    headers: {
      ...headers,
      'content-type': 'application/json'
    },
    body: JSON.stringify({ ...postObj })
    }).then(
        res => res.json(),
        error => console.log('An error occrred at addPost ', error)
    ).then(json => {
      console.log(json)
      dispatch(addPostSuccess(json))
      dispatch(fetchPosts(json.category))
    })
  }
}

export const deletePost = (postId) => {
  return (dispatch) => {
    fetch(`${api}/posts/${postId}`, {
      method: 'DELETE',
      headers: {
        ...headers,
        'content-type': 'application/json'
      }
    }).then(
      res => console.log(res.json()),
      error => console.log('An error occurred at deletePost', error)
    ).then(
      dispatch(fetchPosts("all"))
    )
  }
}

// POST /posts/:id
//   USAGE:
//     Used for voting on a post
//   PARAMS:
//     option - String: Either "upVote" or "downVote"

export const postVote = (postId, string) => {
  console.log(typeof postId, typeof string, string)
  return (dispatch) => {
    fetch(`${api}/posts/${postId}`, {
      method: 'POST',
      headers: {
        ...headers,
        'content-type': 'application/json'
      },
      body: JSON.stringify({ option: string }),
    }).then(res => res.json())
      .then(json => {
        console.log(json)
        // dispatch(postVoteUpSuccess(json));
      })
    }
  }

  //categories

export const beginFetchCategories = () => ({
  type: C.BEGIN_FETCH_CATEGORIES
});

export const fetchCategoriesSuccess = categories => ({
  type: C.FETCH_CATEGORIES_SUCCESS,
  payload: { categories }
});

export const fetchCategoriesFailed = error => ({
  type: C.FETCH_CATEGORIES_FAILED,
  payload: { error }
});

export const getSelectedCategory = selectedCategory => ({
  type: C.GET_SELECTED_CATEGORY,
  payload: { selectedCategory }
})

export function fetchCategories() {
return dispatch => {
  dispatch(beginFetchCategories());
  return fetch(`${api}/categories`, { headers })
    .then(
      res => res.json(),
      error => console.log('An error occured.', error)
    )
    .then(json => {
      dispatch(fetchCategoriesSuccess(json.categories));
      return json.categories;
    })
};
}
// commentsReducer

export function fetchComments(postId) {
  return dispatch => {
    return fetch(`${api}/posts/${postId}/comments`, { headers })
      .then(res => res.json())
      .then(comments => {
        dispatch(fetchCommentsSuccess(postId, comments));
        return comments;
      });
  };
}

export const fetchCommentsSuccess = (postId, comments) => ({
  type: C.FETCH_COMMENTS,
  payload: { postId, comments }
});

 
