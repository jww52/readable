export const api = 'http://localhost:3001'

export const headers = {
  'Accept': 'application/json',
  'Authorization': 'whatever-you-want'
}
